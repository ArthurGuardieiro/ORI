import nltk
import sys

extrator = nltk.stem.RSLPStemmer()
stopwords = nltk.corpus.stopwords.words('portuguese')
#stopwords.append("pra")
caracteresEspecias = [" ", ".", "...", ",", "!", "?", "\n", "\x97"]
caracteresEspeciasForaDaAlgebraBooleana = [" ", ".", "...", ",", "?", "\n", "\x97"]
operadoresDeSeparacao = ["|", "&"]

base = sys.argv[1]
arquivoConsulta = sys.argv[2]

indice = {}

caminhos = []

with open(f'{base}', 'r') as arq:
    linhas = arq.readlines()
    for linha in linhas:
        caminho = linha
        caminho = caminho.replace("\n", "")
        caminhos.append(caminho)

posicaoCaminho = 1

for cam in caminhos:
    with open(cam) as arquivo:
        text = arquivo.read()
        text = text.lower()
        tokens = nltk.wordpunct_tokenize(text)
        tokens = [p for p in tokens if p.lower() not in stopwords and p not in caracteresEspecias]
        for palavra in tokens:
            palavra = extrator.stem(palavra)
            if palavra not in indice:
                indice[f'{palavra}'] = []
                indice[f'{palavra}'].append( [f'{posicaoCaminho}', 1] )
            elif posicaoCaminho != int(indice[f'{palavra}'][-1][0]) :
                #print("entrou no posicaocam != indice")
                #print(posicaoCaminho, indice[f'{palavra}'][-1][0])
                indice[f'{palavra}'].append([f'{posicaoCaminho}', 1])
            else:
                #print(posicaoCaminho, indice[f'{palavra}'][-1][0])
                indice[f'{palavra}'][-1][1] += 1
    posicaoCaminho += 1

with open('indice.txt', 'w') as arqIndice:
    for palavra in indice:
        #print(f'{indice[palavra][0][0]}')
        arqIndice.write(f'{palavra}: ')
        for ind in indice[palavra]:
            arqIndice.write(f'{ind[0]},{ind[1]} ')
        arqIndice.write(f'\n')

with open(f'{arquivoConsulta}', 'r') as arqConsulta:
    busca = arqConsulta.read()
    busca = busca.lower()
    buscaTokens = busca.split(" ")
    buscaTokens = [p for p in buscaTokens if p.lower() not in stopwords and p not in caracteresEspeciasForaDaAlgebraBooleana]

#print(buscaTokens)
palavrasASeremBuscadas = [extrator.stem(p) for p in buscaTokens if p not in operadoresDeSeparacao]
operadoresDeSeparacaoNaConsulta = [p for p in buscaTokens if p in operadoresDeSeparacao]

resultado = []

posicaoTermo=0
for operador in operadoresDeSeparacaoNaConsulta:
    if len(resultado) != 0:
        break
    elif operador == '|':
        if palavrasASeremBuscadas[posicaoTermo][0] != '!':
            if palavrasASeremBuscadas[posicaoTermo] in indice:
                #print(palavrasASeremBuscadas[posicaoTermo])
                for valor in indice[palavrasASeremBuscadas[posicaoTermo]]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    #print(caminhos[indiceInteiroDecrementado])
                    resultado.append(caminhos[indiceInteiroDecrementado])
                    #print(f"primeiro, {resultado}")
        if palavrasASeremBuscadas[posicaoTermo+1][0] != '!':
            if palavrasASeremBuscadas[posicaoTermo+1] in indice:
                #print(palavrasASeremBuscadas[posicaoTermo+1])
                for valor in indice[palavrasASeremBuscadas[posicaoTermo+1]]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    #print(caminhos[indiceInteiroDecrementado])
                    resultado.append(caminhos[indiceInteiroDecrementado])
                    #print(f"segundo, {resultado}")
            resultado = list(set(resultado))
            #print(f'final {resultado}')
    #Operador será '&' AND
    else:
        if palavrasASeremBuscadas[posicaoTermo][0] != '!' and palavrasASeremBuscadas[posicaoTermo+1][0] != "!":
            #print(palavrasASeremBuscadas[posicaoTermo+1])
            listaPrimeiroTermo = []
            listaSegundoTermo = []
            if palavrasASeremBuscadas[posicaoTermo] in indice:
                for valor in indice[palavrasASeremBuscadas[posicaoTermo]]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    #print(caminhos[indiceInteiroDecrementado])
                    listaPrimeiroTermo.append(caminhos[indiceInteiroDecrementado])
                    #print(caminhos[indiceInteiroDecrementado], valor[0])
            if palavrasASeremBuscadas[posicaoTermo+1] in indice:
                #print( '--', palavrasASeremBuscadas[posicaoTermo+1])
                for valor in indice[palavrasASeremBuscadas[posicaoTermo+1]]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    listaSegundoTermo.append(caminhos[indiceInteiroDecrementado])
            if len(listaPrimeiroTermo) != 0 and len(listaSegundoTermo) != 0:
                conjuntoPrimeiroTermo = set(listaPrimeiroTermo)
                conjuntoSegundoTermo = set(listaSegundoTermo)
                conjuntoIntersecao = conjuntoPrimeiroTermo.intersection(conjuntoSegundoTermo)
                for elemento in conjuntoIntersecao:
                    resultado.append(elemento)
        elif palavrasASeremBuscadas[posicaoTermo][0] == '!' and palavrasASeremBuscadas[posicaoTermo+1][0] != "!":
            #print("primeiro neg segundo ok")
            # print(palavrasASeremBuscadas[posicaoTermo+1])
            listaPrimeiroTermo = []
            listaSegundoTermo = []
            primeiraPalavraBuscadaSemNegacao = palavrasASeremBuscadas[posicaoTermo][1::]
            #print(primeiraPalavraBuscadaSemNegacao)
            if primeiraPalavraBuscadaSemNegacao in indice:
                #print('==', primeiraPalavraBuscadaSemNegacao)
                for valor in indice[primeiraPalavraBuscadaSemNegacao]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    # print(caminhos[indiceInteiroDecrementado])
                    listaPrimeiroTermo.append(caminhos[indiceInteiroDecrementado])
                    # print(caminhos[indiceInteiroDecrementado], valor[0])
            if palavrasASeremBuscadas[posicaoTermo + 1] in indice:
                #print('--', palavrasASeremBuscadas[posicaoTermo + 1])
                for valor in indice[palavrasASeremBuscadas[posicaoTermo + 1]]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    listaSegundoTermo.append(caminhos[indiceInteiroDecrementado])
            if len(listaPrimeiroTermo) != 0 and len(listaSegundoTermo) != 0:
                conjuntoPrimeiroTermo = set(listaPrimeiroTermo)
                conjuntoSegundoTermo = set(listaSegundoTermo)
                conjuntoSegundoTermoMenosConjuntoPrimeiroTermo = conjuntoSegundoTermo.difference(conjuntoPrimeiroTermo)
                for elemento in conjuntoSegundoTermoMenosConjuntoPrimeiroTermo:
                    resultado.append(elemento)
        elif palavrasASeremBuscadas[posicaoTermo][0] != '!' and palavrasASeremBuscadas[posicaoTermo+1][0] == "!":
            #print("primeiro ok segundo neg")
            # print(palavrasASeremBuscadas[posicaoTermo+1])
            listaPrimeiroTermo = []
            listaSegundoTermo = []
            if palavrasASeremBuscadas[posicaoTermo] in indice:
                #print('==', palavrasASeremBuscadas[posicaoTermo])
                for valor in indice[palavrasASeremBuscadas[posicaoTermo]]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    #print(caminhos[indiceInteiroDecrementado])
                    listaPrimeiroTermo.append(caminhos[indiceInteiroDecrementado])
                    #print(caminhos[indiceInteiroDecrementado], valor[0])
            #print(palavrasASeremBuscadas[posicaoTermo+1][1::])
            segundaPalavraBuscadaSemNegacao = palavrasASeremBuscadas[posicaoTermo+1][1::]
            #print(segundaPalavraBuscadaSemNegacao)
            if segundaPalavraBuscadaSemNegacao in indice:
                #print('--', segundaPalavraBuscadaSemNegacao)
                for valor in indice[segundaPalavraBuscadaSemNegacao]:
                    indiceInteiroDecrementado = int(valor[0]) - 1
                    listaSegundoTermo.append(caminhos[indiceInteiroDecrementado])
            if len(listaPrimeiroTermo) != 0 and len(listaSegundoTermo) != 0:
                conjuntoPrimeiroTermo = set(listaPrimeiroTermo)
                conjuntoSegundoTermo = set(listaSegundoTermo)
                conjuntoPrimeiroTermoMenosConjuntoSegundoTermo = conjuntoPrimeiroTermo.difference(conjuntoSegundoTermo)
                for elemento in conjuntoPrimeiroTermoMenosConjuntoSegundoTermo:
                    resultado.append(elemento)
    posicaoTermo += 1


#for termo in indice:
#    if extrator.stem(busca) == termo:
#        for valor in indice[termo]:
#            indiceInteiroDecrementado = int(valor[0]) - 1
#            resultado.append(caminhos[indiceInteiroDecrementado])


with open("resposta.txt", 'w') as arqResposta:
    arqResposta.write(f'{len(resultado)}\n')
    for result in resultado:
        arqResposta.write(f'{result}\n')
